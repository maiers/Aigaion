This directory ro/ and its contents should be placed under <aigaionroot>/aigaionengine/language/locale/
